import LoginPage from '../pages/LoginPage'
import ProductsPage from '../pages/ProductsPage'
import ShoppingPage from '../pages/ShoppingPage'
import UserInfoPage from '../pages/UserInfoPage'
import CheckoutPage from '../pages/CheckoutPage'
import FinishPage from '../pages/FinishPage'
import { CREDENTIALS } from '../data/Constants'


fixture('Login testing')
    .page `https://www.saucedemo.com/`

test('Login with a valid user', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)

    await t.expect(ProductsPage.pageTitle.exists).ok()

})

test('Login with an ivalid user', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.INVALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.INVALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)

    await t.expect(LoginPage.errorMsg.exists).ok()
    await t.expect(LoginPage.errorMsg.innerText).eql('Epic sadface: Username and password do not match any user in this service')

})
test('Logout from products page', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.menuBtn)
        .click(ProductsPage.logoutLink)

    await t.expect(LoginPage.loginContainer.exists).ok()
})

test('Navigate to the shopping cart', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.shoppingLink)

    await t.expect(ShoppingPage.pageTitle.exists).ok()
})

test('Add a single item to the shopping cart', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.addCartBtn)
        .click(ProductsPage.shoppingLink)

    await t.expect(ShoppingPage.cartItem.exists).ok()
})

test('Add multiple items to the shopping cart', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.addCartBtn)
        .click(ProductsPage.addCartDosBtn)
        .click(ProductsPage.shoppingLink)

    await t.expect(ShoppingPage.itemName.exists).ok()
    await t.expect(ShoppingPage.itemDosName.exists).ok()
    
})

test('Continue with missing mail/zipcode information', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.shoppingLink)
        .click(ShoppingPage.checkoutBtn)
        .typeText(UserInfoPage.FirstNameField, 'Isis')
        .typeText(UserInfoPage.LastNameField, 'Rojas')
        .click(UserInfoPage.ContinueBtn)

    await t.expect(UserInfoPage.ErrorMsg.exists).ok()
    
})

test('Fill users information', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.shoppingLink)
        .click(ShoppingPage.checkoutBtn)
        .typeText(UserInfoPage.FirstNameField, 'Isis')
        .typeText(UserInfoPage.LastNameField, 'Rojas')
        .typeText(UserInfoPage.ZipCodeField, '44270')
        .click(UserInfoPage.ContinueBtn)

    await t.expect(CheckoutPage.OverwiewTitle.exists).ok()
    
})

test('Final order items', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.addCartBtn)
        .click(ProductsPage.addCartDosBtn)
        .click(ProductsPage.shoppingLink)
        .click(ShoppingPage.checkoutBtn)
        .typeText(UserInfoPage.FirstNameField, 'Isis')
        .typeText(UserInfoPage.LastNameField, 'Rojas')
        .typeText(UserInfoPage.ZipCodeField, '44270')
        .click(UserInfoPage.ContinueBtn)

    await t.expect(CheckoutPage.ItemName.innerText).eql('Sauce Labs Backpack')
    await t.expect(CheckoutPage.ItemTwoName.innerText).eql('Sauce Labs Bolt T-Shirt')
    
})
test('Complete a purchase', async t => {
    await t
        .typeText(LoginPage.userField, CREDENTIALS.VALID_USER.USERNAME)
        .typeText(LoginPage.passwordField, CREDENTIALS.VALID_USER.PASSWORD)
        .click(LoginPage.loginBtn)
        .click(ProductsPage.addCartBtn)
        .click(ProductsPage.addCartDosBtn)
        .click(ProductsPage.shoppingLink)
        .click(ShoppingPage.checkoutBtn)
        .typeText(UserInfoPage.FirstNameField, 'Isis')
        .typeText(UserInfoPage.LastNameField, 'Rojas')
        .typeText(UserInfoPage.ZipCodeField, '44270')
        .click(UserInfoPage.ContinueBtn)
        .click(CheckoutPage.FinishBtn)

    await t.expect(FinishPage.FinishTitle.exists).ok()
    
})
