export const CREDENTIALS = {
 VALID_USER: {
     USERNAME: 'standard_user',
     PASSWORD: 'secret_sauce'
 },
 INVALID_USER:{
     USERNAME:'error_user',
     PASSWORD:'secret_sauce'
 }
}