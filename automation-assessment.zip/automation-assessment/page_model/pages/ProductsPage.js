import { Selector } from 'testcafe'

class ProductsPage{
    constructor(){
        this.pageTitle = Selector('.product_label')
        this.menuBtn = Selector('#react-burger-menu-btn')
        this.logoutLink = Selector('#logout_sidebar_link')
        this.shoppingLink = Selector('#shopping_cart_container a svg path')
        this.addCartBtn = Selector ('#inventory_container div div:nth-child(1) div.pricebar button')
        this.addCartDosBtn = Selector ('#inventory_container div div:nth-child(3) div.pricebar button')
    }
}

export default new ProductsPage()