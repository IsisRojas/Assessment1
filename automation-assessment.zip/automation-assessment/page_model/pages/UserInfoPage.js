import { Selector } from 'testcafe'

class UserInfoPage {
    constructor(){
        this.FirstNameField = Selector('#first-name')
        this.LastNameField = Selector('#last-name')
        this.ZipCodeField = Selector('#postal-code')
        this.ContinueBtn = Selector('.checkout_buttons input')
        this.ErrorMsg = Selector ('#checkout_info_container  div  form  h3')
    }
}

export default new UserInfoPage()