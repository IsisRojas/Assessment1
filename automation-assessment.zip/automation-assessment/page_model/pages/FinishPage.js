import { Selector } from 'testcafe'

class FinishPage {
    constructor(){
        this.FinishTitle = Selector ('div.subheader')
    }
}

export default new FinishPage()