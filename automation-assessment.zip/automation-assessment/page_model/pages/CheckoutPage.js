import { Selector } from 'testcafe'

class CheckoutPage {
    constructor(){
        this.OverwiewTitle = Selector ('#contents_wrapper  div.subheader')
        this.ItemName = Selector ('#item_4_title_link  div')
        this.ItemTwoName = Selector ('#item_1_title_link  div')
        this.FinishBtn = Selector ('.btn_action.cart_button')
    }
}

export default new CheckoutPage()