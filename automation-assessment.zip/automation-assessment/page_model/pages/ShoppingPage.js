import { Selector } from 'testcafe'

class ShoppingPage{
    constructor(){
        this.pageTitle = Selector('.subheader')
        this.cartItem = Selector('.cart_item')
        this.itemName= Selector ('#item_4_title_link div')
        this.itemDosName = Selector ('#item_1_title_link div')
        this.checkoutBtn = Selector ('.btn_action.checkout_button')
        
    }
}

export default new ShoppingPage()