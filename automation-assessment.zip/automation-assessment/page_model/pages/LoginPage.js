import { Selector } from 'testcafe'

class LoginPage {
    constructor(){
        this.loginContainer = Selector ('#login_button_container')
        this.userField = Selector('input[name="user-name"]')
        this.passwordField = Selector('input[name="password"]')
        this.loginBtn = Selector('#login-button')
        this.errorMsg = Selector('#login_button_container div form h3')
    }
}

export default new LoginPage()